﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Husam_Qasim_lec8
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button11_Click(object sender, EventArgs e)
        {
            if (textBox7.Text.Trim() != "")
            {
                int index = textBox1.Text.IndexOf(textBox7.Text, textBox1.SelectionStart+textBox1.SelectionLength);

                if (index > -1)
                {
                    textBox1.Focus();
                    textBox1.Select(index, textBox7.Text.Length);

                }
                else
                    MessageBox.Show("not found");
            }
            else
            {
                MessageBox.Show("ادخل النص المراد البحث عنه");
                textBox7.Focus();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text.Length > 0)
            {
                textBox4.Text = (textBox1.Text.Length).ToString();
                return;
            }
            else
                MessageBox.Show("no text");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (textBox1.SelectedText.Length > 0)
            {
                textBox3.Text = (textBox1.SelectedText.Length).ToString();
                return;
            }
            else
                MessageBox.Show("no text selected");
        }

        private void button7_Click(object sender, EventArgs e)
        {
            if (textBox1.SelectedText.Length > 0)
            {
                Clipboard.SetText(textBox1.SelectedText);
            }
            else
                MessageBox.Show("errer");

        }

        private void button14_Click(object sender, EventArgs e)
        {
            textBox5.Text=Clipboard.GetText();
        }
        
        private void button3_Click(object sender, EventArgs e)
        {
            string[] str = textBox1.Text.Trim().Split(' ');
            textBox2.Text = (str.Length - 1).ToString();
            //string[] strword2 = txtall_text.SelectedText.Split(' ');
            //int X = 0;
            //for (inti= 0; i < strword.Length; i++)
            // if (strword[i] != 1111)
            // x++;
            //textBox2.Text = x.ToString();


        }

        private void button4_Click(object sender, EventArgs e)
        {
            // if (textBox1.SelectedText.Length > 0)
            if (textBox1.SelectionLength > 0)
                {
                // textBox1.Text = textBox1.Text.Remove(textBox1.SelectionStart, textBox1.SelectionLength);
                textBox1.SelectedText = "";
                }
                else
                    MessageBox.Show("selected text");
        }

        private void button6_Click(object sender, EventArgs e)
        {
            textBox1.SelectionLength = 0;
        }

        private void button8_Click(object sender, EventArgs e)
        {
            if (textBox1.SelectedText.Length > 0)
            {
                Clipboard.SetText(textBox1.SelectedText);
                textBox1.SelectedText = " ";

            }
            else
                MessageBox.Show("select text");
        }

        private void button13_Click(object sender, EventArgs e)
        {
            textBox1.Undo();
            textBox5.Undo();

        }

        private void button5_Click(object sender, EventArgs e)
        {
            textBox1.Clear();
        }

        private void button17_Click(object sender, EventArgs e)
        {
            int X = 0;
            for (int i = 0; i < textBox1.Text.Length; i++)
            {
                if (textBox1.Text[i] != ' ')
                {
                    X++;
                }
            }
            MessageBox.Show(X.ToString());

        }

        private void button18_Click(object sender, EventArgs e)
        {
            int x = 0;
            for (int i = 0; i <textBox1.SelectedText.Length; i++)
            {
                if (textBox1.SelectedText[i] != ' ')
                {
                    x++;
                }
            }

            MessageBox.Show(x.ToString());

        }

        private void button9_Click(object sender, EventArgs e)
        {
            if (textBox1.SelectionLength > 0)
            {
                if (textBox6.Text.Trim() != "")
                {
                    // textBox1.Text= textBox1.Text.Replace(textBox1.SelectedText, textBox6.Text);
                    textBox1.SelectedText = textBox6.Text;
                }

                else
                    MessageBox.Show("inter new text");
            }
            else
                MessageBox.Show("select the text to replace");

        }

        private void button10_Click(object sender, EventArgs e)
        {
            if (textBox7.Text.Trim() != "")
            {
                int index = textBox1.Text.IndexOf(textBox7.Text, 0);

                if (index > -1)
                {
                    textBox1.SelectionStart = index;
                    textBox1.SelectionLength = textBox7.Text.Length;

                     //textBox1.Select(index, textBox7.Text.Length);
                    textBox1.Focus();
                }
                else
                    MessageBox.Show("not found");
            }
            else
            {
                MessageBox.Show("ادخل النص المراد البحث عنه");
                textBox7.Focus();
            }
       
        }

        private void button12_Click(object sender, EventArgs e)
        {
            if (textBox7.Text.Trim() != "")
            {
                int index = textBox1.Text.IndexOf(textBox7.Text, textBox1.SelectionStart - textBox1.SelectionLength);

                if (index > -1)
                {
                    textBox1.Focus();
                    textBox1.Select(index, textBox7.Text.Length);
                }
                else
                    MessageBox.Show("not found");
            }
            else
            {
                MessageBox.Show("ادخل النص المراد البحث عنه");
                textBox7.Focus();
            }
        }

        private void button16_Click(object sender, EventArgs e)
        {
            listBox2.Items.Clear();
            string[] s =textBox1.SelectedText.Split(' ');
            for (int i = 0; i < s.Length; i++)
                
                listBox2.Items.Add(s[i]);
        

    }

    private void button15_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
            string str = textBox1.SelectedText;
            char[] ch = str.ToCharArray();
            for (int i = 0; i < ch.Length; i++)

                listBox1.Items.Add(ch[i]);
        }
    }
}

 

