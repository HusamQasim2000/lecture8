﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Husam_Qasim_lec8
{
    public partial class Form3_HW3 : Form
    {
        public Form3_HW3()
        {
            InitializeComponent();
        }

        private void Form3_HW3_Load(object sender, EventArgs e)
        {
            listBox1.SelectionMode = SelectionMode.MultiSimple;
            Random r = new Random();
            for(int i = 0; i < 10; i++)
            {
               int p =  r.Next(100);
                listBox1.Items.Add(p);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (!(listBox1.Items.Contains(textBox1.Text.Trim())) && Convert.ToInt16(textBox1.Text) < 100)
                listBox1.Items.Add(textBox1.Text);
            else
                MessageBox.Show("no repeat");
            textBox1.Clear();
            textBox1.Focus();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (listBox1.SelectedIndex > 0)
            {
                listBox1.Items.RemoveAt(listBox1.SelectedIndex);
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            while( listBox1.Items.Count>0)
            {
                listBox1.Items.Remove(listBox1.Items[0]);
            }
        }
        int sum = 0;

        private void button4_Click(object sender, EventArgs e)
        {
            if (listBox1.Items.Count <= 20)
            {
                for (int i = 0; i < listBox1.Items.Count; i++)
                {
                    sum += Convert.ToInt32(listBox1.Items[i]);
                }
                textBox2.Text = sum.ToString();
            }
            else
                MessageBox.Show("less of 20 items");


        }
        double aver = 0.0;
        private void button5_Click(object sender, EventArgs e)
        {
            if (listBox1.Items.Count <= 20)
            {
                for (int i = 0; i < listBox1.Items.Count; i++)
                {
                    sum += Convert.ToInt32(listBox1.Items[i]);
                }
                aver = (sum / listBox1.Items.Count);
                textBox3.Text = aver.ToString();
            }
            else
                MessageBox.Show("less of 20 items");

        }
    }
}
