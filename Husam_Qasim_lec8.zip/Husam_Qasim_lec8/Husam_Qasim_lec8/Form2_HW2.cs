﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Husam_Qasim_lec8
{
    public partial class Form2_HW2 : Form
    {
        List<string> undoStack = new List<string>();
        int currentUndoIndex = -1;

        public Form2_HW2()
        {
            InitializeComponent();
        }
        string copiedText = string.Empty;
        //copy
        private void button1_Click(object sender, EventArgs e)
        {
            copiedText = textBox1.SelectedText;

        }

        private void button2_Click(object sender, EventArgs e)
        {
            copiedText = textBox1.SelectedText;
            textBox1.Text = textBox1.Text.Remove(textBox1.SelectionStart, textBox1.SelectionLength);
            SaveState(); // حفظ حالة النصوص للتراجع.

        }

        private void button4_Click(object sender, EventArgs e)
        {
            textBox2.Text = textBox2.Text.Insert(textBox2.SelectionStart, copiedText);
            SaveState();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (currentUndoIndex > 0)
            {
                currentUndoIndex--;
                RestoreState();
            }
        }
            private void SaveState()
        {
            if (currentUndoIndex < undoStack.Count - 1)
            {
                undoStack.RemoveRange(currentUndoIndex + 1, undoStack.Count - currentUndoIndex - 1);
            }
            undoStack.Add(textBox1.Text + "|" + textBox2.Text);
            currentUndoIndex = undoStack.Count - 1;

            if (undoStack.Count > 10)
            {
                undoStack.RemoveAt(0);
                currentUndoIndex--;
            }
        }
       
            
        
        
        private void RestoreState()
        {
            string[] states = undoStack[currentUndoIndex].Split('|');
            textBox1.Text = states[0];
            textBox2.Text = states[1];
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}

